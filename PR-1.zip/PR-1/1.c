#include<stdio.h>
main (){
	
	float f,c;
	printf("enter value of c :- ");
	scanf("%f",&c);
	f = c*9/5+32;
	printf("%f",f);
	
}
