#include<stdio.h>
main(){
	
	char i='A';
	
	do{
		printf("%c ",i);
		i++;
		i++;
		i++;
		i++;
	}
	while(i<='Z');
	
}
