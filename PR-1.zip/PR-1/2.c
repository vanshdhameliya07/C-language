#include<stdio.h>
main () {
	
	int hra,da,ta,ans;
	printf("enter value of hra :- ");
	scanf("%d",&hra);
	printf("enter value of da :- ");
	scanf("%d",&da);
	printf("enter value of ta :- ");
	scanf("%d",&ta);
	ans=100+(hra+da+ta);
	printf("%d",ans);
	
	
}
