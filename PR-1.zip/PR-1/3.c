#include<stdio.h>
main (){
	
	int fa,sa,ans;
	printf("enter value of fa :- ");
	scanf("%d",&fa);
	printf("enter value of sa :- ");
	scanf("%d",&sa);
	ans= 180-(fa + sa);
	printf("%d",ans);
}
